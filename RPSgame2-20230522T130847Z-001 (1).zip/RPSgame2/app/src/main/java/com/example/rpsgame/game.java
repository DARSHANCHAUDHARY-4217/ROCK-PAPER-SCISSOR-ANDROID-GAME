package com.example.rpsgame;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URL;
import java.util.Random;

public class game extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    TextView userSelectionTextView, compSelectionTextView, wonLostTieTextView, scoreTextVIEW;
    Button logout;
    Button rules , FAQs ;

    int userScore = 0, compScore = 0;
    Random random;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        userSelectionTextView = findViewById(R.id.userSelectionTextView);
        compSelectionTextView = findViewById(R.id.compSelectionTextView);
        wonLostTieTextView = findViewById(R.id.wonLostTieTextView);
        scoreTextVIEW = findViewById(R.id.scoreTextVIEW);
        logout = findViewById(R.id.Logout);
        rules = findViewById(R.id.rules);
        FAQs = findViewById(R.id.faq);

        userSelectionTextView.setText("");
        compSelectionTextView.setText("");
        wonLostTieTextView.setText("");

        random = new Random();

        rules.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(game.this,Rules.class);
                startActivity(in);
                Toast.makeText(game.this,"RULES",Toast.LENGTH_SHORT).show();
            }
        });

        FAQs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                golink("https://www.paperrockscissor.com/frequently-asked-questions");
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(game.this,Login.class);
                startActivity(intent);
                finish();
                Toast.makeText(game.this, "Successfully Logged Out", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void golink(String s) {
        Uri uri = Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));
    }

    public void resetButton(View view) {
        wonLostTieTextView.setText("");
        userSelectionTextView.setText("");
        compSelectionTextView.setText("");
        userScore = 0;
        compScore = 0;
        setScoreTextVIEW(userScore, compScore);

    }

    public void rpsButtonSelected(View view) {
        int userSelection = Integer.parseInt(view.getTag().toString());
        Log.i(TAG, "rpsButtonSelected: " + userSelection);
        matchGame(userSelection);
    }
    private void matchGame(int userSelection){
        int low=1;
        int high=3;

        int compSelection = random.nextInt(high) + low ;
        if (userSelection == compSelection){
            //Tie
            wonLostTieTextView.setText("It's a Tie!");
        }
        else if ((userSelection - compSelection) % 3 ==1){
            //User Win
            userScore++;
            wonLostTieTextView.setText("yay,you won!");
        }
        else{
            //comp wins
            compScore++;
            wonLostTieTextView.setText("Oops,you Lost!");
        }
        switch (userSelection){
            case 1:
                userSelectionTextView.setText("Rock");
                break;
            case 2:
                userSelectionTextView.setText("Paper");
                break;
            case 3:
                userSelectionTextView.setText("Scissor");
                break;
        }

        switch (compSelection){
            case 1:
                compSelectionTextView.setText("Rock");
                break;
            case 2:
                compSelectionTextView.setText("Paper");
                break;
            case 3:
                compSelectionTextView.setText("Scissor");
                break;
        }

        setScoreTextVIEW(userScore,compScore);
    }
    private void setScoreTextVIEW(int userScore, int compScore){
        scoreTextVIEW.setText(String.valueOf(userScore)+ ":" + String.valueOf(compScore));
    }

    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setMessage("Are You Sure you want to end the game?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                    }
                })
                .setNegativeButton("No",null)
                .show();
    }

    public void Logout(View v){
        moveTaskToBack(true);
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(1);
    }
}